#ifndef COMPEL_PLUGIN_STD_STD_H__
#define COMPEL_PLUGIN_STD_STD_H__

extern int __must_check fds_send_fd(int fd);
extern int fds_recv_fd(void);

#endif /* COMPEL_PLUGIN_STD_STD_H__ */
